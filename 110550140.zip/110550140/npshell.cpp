#include<unistd.h>
#include<vector>
#include<iostream>
#include<fcntl.h>

#include "Shell.h"

int main(){
    Shell shell;
    shell.run();
    
}