#ifndef IOMANAGER_H
#define IOMANAGER_H
#include<iostream>
#include<string>

class IOManager{
public:
    static std::string getInput();
};

#endif